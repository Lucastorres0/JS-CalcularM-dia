function media() {
    var nome = window.prompt("Qual o seu nome?")
    var n1 = Number(window.prompt("Digite a primeira o nota:"))
    var n2 = Number(window.prompt("Digite a segunda nota:"))

    med = (n1 + n2) / 2

    var msg
    if(med >= 5) {
        msg = "Parabéns, você foi aprovado!"
    }else {
        msg = "Você foi reprovado!"
    }

    var res = document.getElementById("situacao")
    res.innerHTML = `Olá, ${nome} sua média é ${med}!`
    res.innerHTML = `<p>E a mensagem que temos é: 
    <h1 style= "color: red;">${msg}</h1></p>`
}