function adicao() {
    var n1 = Number(window.prompt('Digite um número:'))
    var n2 = Number(window.prompt('Digite outro número:'))

    var res = document.querySelector('section#res')
    res.innerHTML = `<span>A soma entre ${n1} e ${n2} é igual a ${n1 + n2}</span>`
}

function subtracao() {
    var n3 = Number(window.prompt('Digite um número'))
    var n4 = Number(window.prompt('Digite outro número'))

    var res2 = document.querySelector('section#res2')
    res2.innerHTML = `<span>A subtração entre ${n3} e ${n4} é igual a ${n3 - n4}</span>`
}

function multiplicacao() {
    var n5 = Number(window.prompt('Digite um número'))
    var n6 = Number(window.prompt('Digite outro número'))

    var res3 = document.querySelector('section#res3')
    res3.innerHTML = `<span>A multiplicação entre ${n5} e ${n6} é igual a ${n5 * n6}</span>`
}

function divisao() {
    var n7 = Number(window.prompt('Digite um número'))
    var n8 = Number(window.prompt('Digite outro número'))

    var res4 = document.querySelector('section#res4')
    res4.innerHTML = `<span>A divisão entre ${n7} e ${n8} é igual a ${n7 / n8}</span>`
}

function potenciacao() {
    var n9 = Number(window.prompt('Digite um número'))
    var n10 = Number(window.prompt('Digite o expoente'))

    var res5 = document.querySelector('section#res5')
    res5.innerHTML = `<span>A potenciação de ${n9} e ${n10} é igual a ${n9 ** n10}</span>`
}

//function somar2() {
//    var some = Number
//}